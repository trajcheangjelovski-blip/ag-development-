'use client'
import { useState } from 'react'
import Link from 'next/link'

const services = [
  {
    id: 'website-dev',
    icon: '🌐', iconBg: '#eff6ff', accent: '#2563eb', badgeBg: '#dbeafe', badgeText: '#1d4ed8',
    badge: 'Еднократно',
    title: 'Изработка на веб страна',
    subtitle: 'Нова веб страна',
    description: 'Професионални WordPress, WooCommerce и бизнис веб страни — изработени да привлекуваат клиенти и да го претставуваат вашиот бизнис.',
    cta: 'Погледни пакети →',
    href: '/pricing#website-build',
  },
  {
    id: 'website-care',
    icon: '🛡️', iconBg: '#f0fdf4', accent: '#16a34a', badgeBg: '#dcfce7', badgeText: '#166534',
    badge: 'Месечно',
    title: 'Одржување и хостинг',
    subtitle: 'Месечна грижа за страната',
    description: 'Хостинг, бекапи, ажурирања, безбедносни проверки, промени на содржина и техничка поддршка секој месец.',
    cta: 'Погледни планови →',
    href: '/order/website-care',
  },
  {
    id: 'it-support',
    icon: '💻', iconBg: '#f1f5f9', accent: '#334155', badgeBg: '#e2e8f0', badgeText: '#334155',
    badge: 'Месечно',
    title: 'IT Поддршка',
    subtitle: 'Месечна поддршка за тим',
    description: 'Прва линија IT поддршка за вашите вработени — ресетирање лозинки, проблеми со софтвер, печатачи, скенери, емаил и далечинско решавање.',
    cta: 'Погледни IT планови →',
    href: '/order/it-support',
  },
  {
    id: 'social-media',
    icon: '🎨', iconBg: '#fdf4ff', accent: '#7c3aed', badgeBg: '#ede9fe', badgeText: '#5b21b6',
    badge: 'Месечно',
    title: 'Социјални мрежи и дизајн',
    subtitle: 'Месечни содржини',
    description: 'Брендирани објави, приказни, банери и промотивна графика — дизајнирани за вашиот бизнис на Facebook и Instagram.',
    cta: 'Погледни дизајн планови →',
    href: '/order/social-media',
  },
  {
    id: 'business-email',
    icon: '📧', iconBg: '#fff7ed', accent: '#ea580c', badgeBg: '#fed7aa', badgeText: '#9a3412',
    badge: 'Техничка помош',
    title: 'Бизнис емаил',
    subtitle: 'Поставување и управување',
    description: 'Microsoft 365, Google Workspace, поставување сандаче, SPF/DKIM записи, пренасочување на емаили и основно решавање проблеми.',
    cta: 'Побарај поставување →',
    href: '/contact?service=business-email',
  },
  {
    id: 'domain-dns',
    icon: '🌍', iconBg: '#f0fdf4', accent: '#0f766e', badgeBg: '#ccfbf1', badgeText: '#0f766e',
    badge: 'Техничка помош',
    title: 'Домен, DNS и SSL',
    subtitle: 'Техничко поставување',
    description: 'Поврзување домен, DNS записи, SSL сертификати, пренасочувања, поставување хостинг и основно решавање проблеми.',
    cta: 'Побарај помош →',
    href: '/contact?service=domain-dns',
  },
  {
    id: 'graphic-design',
    icon: '🖼️', iconBg: '#fff1f2', accent: '#9f1239', badgeBg: '#fecdd3', badgeText: '#9f1239',
    badge: 'По договор',
    title: 'Графички дизајн',
    subtitle: 'Дизајн по потреба',
    description: 'Логоа, флаери, банери, визит-картички, графики за веб страна и промотивни материјали за вашиот бренд.',
    cta: 'Побарај дизајн →',
    href: '/contact?service=graphic-design',
  },
  {
    id: 'custom-platforms',
    icon: '⚡', iconBg: '#fefce8', accent: '#92400e', badgeBg: '#fef08a', badgeText: '#854d0e',
    badge: 'По договор',
    title: 'Прилагодени платформи',
    subtitle: 'Веб апликации и алатки',
    description: 'Клиентски портали, системи за резервации, контролни табли, интерни алатки и прилагодени веб апликации.',
    cta: 'Разговарај за проект →',
    href: '/contact?service=custom-platform',
  },
]

export function ServicesSection() {
  const [hoveredCard, setHoveredCard] = useState<string | null>(null)

  return (
    <section style={{ padding: '80px 24px', background: 'white' }}>
      <style>{`
        @media (max-width: 1023px) { .ss-grid { grid-template-columns: repeat(2, 1fr) !important; } }
        @media (max-width: 767px)  { .ss-grid { grid-template-columns: 1fr !important; } }
        .ss-btn-ghost { transition: transform 0.18s ease, background 0.18s ease, border-color 0.18s ease, box-shadow 0.18s ease !important; }
        .ss-btn-ghost:hover { transform: translateY(-2px) scale(1.02); background: rgba(255,255,255,0.1) !important; border-color: rgba(255,255,255,0.6) !important; box-shadow: 0 8px 24px rgba(0,0,0,0.2); }
        .ss-btn-ghost:active { transform: translateY(0) scale(0.98); }
        .ss-btn-primary { transition: transform 0.18s ease, box-shadow 0.18s ease, filter 0.18s ease !important; }
        .ss-btn-primary:hover { transform: translateY(-2px) scale(1.02); box-shadow: 0 12px 32px rgba(37,99,235,0.55) !important; filter: brightness(1.12); }
        .ss-btn-primary:active { transform: translateY(0) scale(0.98); filter: brightness(0.97); }
      `}</style>

      <div style={{ maxWidth: 1100, margin: '0 auto' }}>
        <div style={{ marginBottom: 48, maxWidth: 700 }}>
          <div style={{ fontSize: 11, fontWeight: 700, textTransform: 'uppercase' as const, letterSpacing: '0.12em', color: '#2563eb', marginBottom: 12 }}>ШТО ПРАВИМЕ</div>
          <h2 style={{ fontSize: 'clamp(26px, 3.5vw, 38px)', fontWeight: 800, color: '#0f1f3d', marginBottom: 14, fontFamily: 'var(--font-display, Outfit, sans-serif)', lineHeight: 1.15 }}>
            Еден партнер за вашата веб страна, IT поддршка и дигитален раст
          </h2>
          <p style={{ fontSize: 16, color: '#64748b', lineHeight: 1.8, maxWidth: 640, margin: '0 0 12px' }}>
            Од изградба на веб страната до нејзино одржување, поддршка на тимот, управување со бизнис емаил и создавање брендирана содржина — AG Development му помага на вашиот бизнис да биде професионален онлајн.
          </p>
          <p style={{ fontSize: 16, color: '#334155', lineHeight: 1.8, maxWidth: 640, margin: 0, fontWeight: 500 }}>
            Потребна ви е комбинација на услуги? Изградете прилагоден месечен план според потребите и буџетот на вашиот бизнис.
          </p>
        </div>

        <div className="ss-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 20 }}>
          {services.map(card => {
            const hov = hoveredCard === card.id
            return (
              <div key={card.id}
                onMouseEnter={() => setHoveredCard(card.id)}
                onMouseLeave={() => setHoveredCard(null)}
                style={{ background: 'white', border: '1px solid #e2e8f0', borderRadius: 16, padding: '28px 24px', position: 'relative' as const, display: 'flex', flexDirection: 'column' as const, transition: 'all 0.25s cubic-bezier(0.4, 0, 0.2, 1)', transform: hov ? 'translateY(-5px)' : 'translateY(0)', boxShadow: hov ? '0 16px 40px rgba(0,0,0,0.10)' : '0 1px 4px rgba(0,0,0,0.05)', cursor: 'pointer' }}
              >
                <div style={{ position: 'absolute', top: -1, left: -1, right: -1, height: hov ? 4 : 2, borderRadius: '16px 16px 0 0', background: card.accent, transition: 'height 0.2s ease', zIndex: 1 }} />
                <span style={{ position: 'absolute', top: 14, right: 14, fontSize: 10, fontWeight: 700, padding: '3px 9px', borderRadius: 100, textTransform: 'uppercase' as const, letterSpacing: '0.06em', background: card.badgeBg, color: card.badgeText }}>{card.badge}</span>
                <div style={{ width: 52, height: 52, borderRadius: 14, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24, marginBottom: 14, background: card.iconBg, transition: 'transform 0.2s ease', transform: hov ? 'scale(1.1)' : 'scale(1)' }}>{card.icon}</div>
                <div style={{ fontSize: 11, fontWeight: 600, textTransform: 'uppercase' as const, letterSpacing: '0.06em', color: '#94a3b8', marginBottom: 6 }}>{card.subtitle}</div>
                <h3 style={{ fontSize: 17, fontWeight: 700, color: '#0f1f3d', marginBottom: 8, fontFamily: 'var(--font-display, Outfit, sans-serif)' }}>{card.title}</h3>
                <p style={{ fontSize: 13, color: '#64748b', lineHeight: 1.7, flex: 1, marginBottom: 16 }}>{card.description}</p>
                <Link href={card.href} style={{ display: 'inline-flex', alignItems: 'center', gap: hov ? 8 : 5, fontSize: 13, fontWeight: 600, color: card.accent, textDecoration: 'none', marginTop: 'auto' as const, transition: 'gap 0.2s ease' }}>{card.cta}</Link>
              </div>
            )
          })}
        </div>

        <div style={{ marginTop: 48, borderRadius: 24, overflow: 'hidden' as const, background: 'linear-gradient(135deg, #060e1e 0%, #0f1f3d 50%, #162b52 100%)', padding: 'clamp(32px, 5vw, 56px)' }}>
          <div style={{ maxWidth: 760, margin: '0 auto', textAlign: 'center' as const }}>
            <h3 style={{ fontSize: 'clamp(24px, 3vw, 32px)', fontWeight: 800, color: 'white', marginBottom: 18, fontFamily: 'var(--font-display, Outfit, sans-serif)', lineHeight: 1.2 }}>
              Потребна ви е поддршка без вработување на полно работно време?
            </h3>
            <p style={{ fontSize: 15, color: 'rgba(255,255,255,0.6)', lineHeight: 1.8, marginBottom: 14 }}>
              Многу мали бизниси имаат потреба од IT поддршка, одржување на веб страна, управување со емаил и дизајн — но вработувањето на полно работно лице може да биде скапо.
            </p>
            <p style={{ fontSize: 15, color: 'rgba(255,255,255,0.78)', lineHeight: 1.8, marginBottom: 28, fontWeight: 600 }}>
              Изградете прилагоден месечен план кој одговара на вашиот бизнис и буџет.
            </p>
            <div style={{ display: 'flex', flexWrap: 'wrap' as const, gap: 14, justifyContent: 'center' }}>
              <Link href="/services" className="ss-btn-ghost" style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '14px 30px', background: 'transparent', color: 'white', border: '1.5px solid rgba(255,255,255,0.25)', borderRadius: 12, fontSize: 15, fontWeight: 700, textDecoration: 'none' }}>
                Погледни ги сите услуги →
              </Link>
              <Link href="/order/custom-plan" className="ss-btn-primary" style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '14px 30px', background: '#2563eb', color: 'white', borderRadius: 12, fontSize: 15, fontWeight: 700, textDecoration: 'none', boxShadow: '0 8px 24px rgba(37,99,235,0.35)' }}>
                Изгради прилагоден план →
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
