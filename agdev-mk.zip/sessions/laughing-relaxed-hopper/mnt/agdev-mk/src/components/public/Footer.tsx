import Link from 'next/link'
import { LogoMark } from '@/components/public/Logo'

export function PublicFooter() {
  return (
    <footer style={{ background: '#0a1628' }} className="text-white/50 pt-16 pb-8">
      <div className="max-w-6xl mx-auto px-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-10 pb-12 border-b border-white/10">
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-2.5 mb-4">
              <LogoMark size={32} />
              <span className="font-display font-bold text-white text-sm">AG Development</span>
            </div>
            <p className="text-sm leading-relaxed max-w-xs">Веб страни и IT поддршка за мали бизниси во Македонија. Без скриени трошоци.</p>
          </div>
          <div>
            <h4 className="text-white font-semibold text-sm mb-4">Услуги</h4>
            <div className="space-y-2.5">
              {['Изработка на веб страна','WordPress поддршка','Онлајн продавница','Домен и DNS','Бизнис емаил','IT поддршка'].map(s => (
                <Link key={s} href="/services" className="block text-sm hover:text-white/80 transition-colors">{s}</Link>
              ))}
            </div>
          </div>
          <div>
            <h4 className="text-white font-semibold text-sm mb-4">Компанија</h4>
            <div className="space-y-2.5">
              {[['Портфолио','/portfolio'],['Ценовник','/pricing'],['Бесплатна ревизија','/review'],['Контакт','/contact'],['Клиентски портал','/login']].map(([l,h]) => (
                <Link key={l} href={h} className="block text-sm hover:text-white/80 transition-colors">{l}</Link>
              ))}
            </div>
          </div>
          <div>
            <h4 className="text-white font-semibold text-sm mb-4">Контакт</h4>
            <div className="space-y-2.5 text-sm">
              <div>info@ag-development.mk</div>
              <div>Одговор до 1 работен ден</div>
              <div>Пон–Пет, 9:00–18:00 ч</div>
              <div>Македонија — Далечинска поддршка</div>
            </div>
          </div>
        </div>
        <div className="pt-8 flex flex-col md:flex-row justify-between gap-4 text-xs">
          <span>© 2025 AG Development. Сите права задржани.</span>
          <span>Веб страни и IT поддршка за мали бизниси во Македонија</span>
        </div>
      </div>
    </footer>
  )
}
