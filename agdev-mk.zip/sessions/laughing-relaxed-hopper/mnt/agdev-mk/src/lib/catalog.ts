// Single source of truth for everything purchasable on the site.
// Prices in MKD (Македонски денари).

export type CatalogItem = {
  id: string
  name: string
  price: number
  interval: 'month' | null
  category: 'Website Build' | 'Website Care' | 'IT Support' | 'Social Media'
  description: string
}

export const CATALOG: CatalogItem[] = [
  // One-time website builds
  { id: 'starter-site',    name: 'Стартер Веб',   price: 9900,  interval: null,    category: 'Website Build', description: '1-страна професионална веб страна' },
  { id: 'business-site',   name: 'Бизнис Веб',    price: 19900, interval: null,    category: 'Website Build', description: 'До 5 страни — најпопуларно' },
  { id: 'premium-site',    name: 'Премиум Веб',   price: 29900, interval: null,    category: 'Website Build', description: 'До 8 страни со блог и напреден SEO' },
  { id: 'ecommerce-store', name: 'Онлајн Продавница', price: 49900, interval: null, category: 'Website Build', description: 'WooCommerce / Shopify продавница' },

  // Monthly website care plans
  { id: 'basic-care',   name: 'Основен план',  price: 1900, interval: 'month', category: 'Website Care', description: 'Хостинг, бекапи и безбедносни ажурирања' },
  { id: 'content-care', name: 'Содржина план', price: 2900, interval: 'month', category: 'Website Care', description: '+ 30 мин/месец ажурирање на содржина' },
  { id: 'growth-care',  name: 'Раст план',     price: 4900, interval: 'month', category: 'Website Care', description: '+ 1 час/месец ажурирања на страна' },
  { id: 'full-care',    name: 'Целосен план',  price: 7900, interval: 'month', category: 'Website Care', description: '+ 2 часа/месец, приоритетна поддршка' },

  // Monthly L1 IT support
  { id: 'it-basic',  name: 'Основна IT поддршка', price: 2900,  interval: 'month', category: 'IT Support', description: '3 барања/мес, до 2 корисници' },
  { id: 'it-team',   name: 'Тимска IT поддршка',  price: 5900,  interval: 'month', category: 'IT Support', description: '8 барања/мес, до 5 корисници' },
  { id: 'it-office', name: 'Канцелариска поддршка', price: 9900, interval: 'month', category: 'IT Support', description: '15 барања/мес, до 10 корисници' },

  // Extra credits
  { id: 'extra-hour', name: 'Дополнителен час', price: 1900, interval: null, category: 'IT Support', description: '1 дополнителен час поддршка' },

  // Monthly social media & design
  { id: 'social-starter',  name: 'Социјал Стартер', price: 1900, interval: 'month', category: 'Social Media', description: '2 објави/приказни месечно' },
  { id: 'social-business', name: 'Социјал Бизнис',  price: 3500, interval: 'month', category: 'Social Media', description: '6 објави + 1 банер месечно' },
  { id: 'social-growth',   name: 'Социјал Раст',    price: 5900, interval: 'month', category: 'Social Media', description: '12 објави + 2 банери месечно' },
]

export function getCatalogItem(id: string): CatalogItem | undefined {
  return CATALOG.find(i => i.id === id)
}
