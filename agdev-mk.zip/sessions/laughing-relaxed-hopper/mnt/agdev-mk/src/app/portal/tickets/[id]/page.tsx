import { createClient } from '@/lib/supabase/server'
import { redirect, notFound } from 'next/navigation'
import PortalLayout from '@/components/portal/PortalLayout'
import TicketDetailClient from '@/components/portal/TicketDetailClient'
import { clientCan } from '@/lib/permissions'

export default async function ClientTicketDetail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/login')

  const { data: profile } = await supabase.from('profiles').select('*').eq('id', user.id).single()
  if (!profile?.client_id) redirect('/login')

  const { data: ticket } = await supabase
    .from('tickets')
    .select('*, client:clients(*, package:support_packages(*)), creator:profiles!created_by(id, full_name, role)')
    .eq('id', id)
    .eq('client_id', profile.client_id) // ensure client can only see own tickets
    .single()

  if (!ticket) notFound()
  // Members restricted to their own tickets can't open a teammate's
  if (!clientCan(profile as any, 'allTickets') && ticket.created_by !== user.id) notFound()

  return (
    <PortalLayout>
      <TicketDetailClient ticketId={id} initialTicket={ticket} profile={profile} />
    </PortalLayout>
  )
}
