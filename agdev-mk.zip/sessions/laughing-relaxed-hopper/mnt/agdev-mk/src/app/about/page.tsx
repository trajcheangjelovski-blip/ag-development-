import { PublicHeader } from '@/components/public/Header'
import { PublicFooter } from '@/components/public/Footer'
import Link from 'next/link'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'За нас',
  description: 'AG Development — веб страни, IT поддршка и дизајн за мали бизниси во Македонија.',
  alternates: { canonical: 'https://ag-development.mk/about' },
}

export default function AboutPage() {
  return (
    <>
      <PublicHeader />

      <section className="text-white py-16 px-6" style={{ background: 'linear-gradient(135deg, #0f1f3d 0%, #162b52 100%)' }}>
        <div className="max-w-2xl">
          <div className="text-xs font-bold uppercase tracking-widest text-blue-400 mb-3">За нас</div>
          <h1 className="font-display text-4xl font-extrabold text-white mb-4">Еден партнер за сè дигитално</h1>
          <p className="text-white/75 text-lg">AG Development е дигитална агенција која им помага на мали бизниси во Македонија да изгледаат и работат profesionalno онлајн.</p>
        </div>
      </section>

      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 mb-16">
            <div>
              <h2 className="font-display text-2xl font-extrabold text-slate-800 mb-4">Нашата мисија</h2>
              <p className="text-slate-600 leading-relaxed mb-4">
                Веруваме дека секој мал бизнис во Македонија заслужува пристапна, доверлива и транспарентна техничка поддршка — без потреба да вработи полно работно лице.
              </p>
              <p className="text-slate-600 leading-relaxed">
                Нудиме веб страни, IT поддршка, бизнис емаил и дизајн на социјални мрежи — сè во еден прилагоден месечен план.
              </p>
            </div>
            <div>
              <h2 className="font-display text-2xl font-extrabold text-slate-800 mb-4">Зошто ние?</h2>
              <div className="space-y-3">
                {[
                  ['✓', 'Фиксни месечни цени — без изненадувања'],
                  ['✓', 'Доказ за секоја завршена задача'],
                  ['✓', 'Брз одговор — до 3 часа'],
                  ['✓', 'Јасна комуникација на македонски'],
                  ['✓', 'Прилагодени пакети за секој бизнис'],
                ].map(([icon, text]) => (
                  <div key={text} className="flex items-center gap-3 text-slate-700">
                    <span className="text-blue-600 font-bold">{icon}</span>
                    <span className="text-sm">{text}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="grid sm:grid-cols-3 gap-6 mb-16">
            {[['50+', 'Задоволни клиенти'], ['200+', 'Завршени проекти'], ['3 часа', 'Просечно време на одговор']].map(([num, label]) => (
              <div key={label} className="text-center p-6 rounded-xl bg-slate-50 border border-slate-200">
                <div className="font-display text-4xl font-extrabold text-blue-600 mb-2">{num}</div>
                <div className="text-slate-600 text-sm font-medium">{label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 px-6 text-center text-white" style={{ background: '#0f1f3d' }}>
        <h2 className="font-display text-3xl font-extrabold mb-3">Подготвени да соработуваме?</h2>
        <p className="text-white/70 mb-7">Стапете во контакт и ќе ви одговориме во рок од 3 часа.</p>
        <div className="flex flex-wrap justify-center gap-3">
          <Link href="/contact" className="btn-primary px-7 py-3.5">Контактирајте нè →</Link>
          <Link href="/review" className="btn-outline-white px-7 py-3.5">Бесплатна ревизија</Link>
        </div>
      </section>

      <PublicFooter />
    </>
  )
}
