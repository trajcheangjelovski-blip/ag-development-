import type { Metadata } from 'next'
import { Outfit, Inter } from 'next/font/google'
import { CartProvider } from '@/components/public/Cart'
import { ChatWidget } from '@/components/public/ChatWidget'
import './globals.css'

const outfit = Outfit({
  subsets: ['latin', 'cyrillic-ext'],
  variable: '--font-outfit',
  display: 'swap',
})

const inter = Inter({
  subsets: ['latin', 'cyrillic-ext'],
  variable: '--font-inter',
  display: 'swap',
})

export const metadata: Metadata = {
  metadataBase: new URL('https://ag-development.mk'),
  title: {
    default: 'AG Development — Веб страни, IT Поддршка и Дизајн за Мали Бизниси',
    template: '%s | AG Development',
  },
  description: 'Професионални веб страни, IT поддршка, бизнис емаил, дизајн на социјални мрежи и дигитален раст за мали бизниси во Македонија.',
  keywords: ['веб страна Македонија', 'IT поддршка', 'изработка на веб страна', 'WordPress Македонија', 'дизајн на социјални мрежи', 'одржување веб страна', 'AG Development'],
  authors: [{ name: 'AG Development', url: 'https://ag-development.mk' }],
  creator: 'AG Development',
  openGraph: {
    type: 'website',
    locale: 'mk_MK',
    url: 'https://ag-development.mk',
    siteName: 'AG Development',
    title: 'AG Development — Веб страни, IT Поддршка и Дизајн за Мали Бизниси',
    description: 'Професионални веб страни, IT поддршка и дигитален раст за мали бизниси во Македонија.',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'AG Development — Веб страни, IT Поддршка и Дизајн',
    description: 'Веб страни, IT поддршка и дигитален раст за мали бизниси во Македонија.',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, 'max-video-preview': -1, 'max-image-preview': 'large', 'max-snippet': -1 },
  },
  alternates: { canonical: 'https://ag-development.mk' },
}

const orgSchema = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  name: 'AG Development',
  url: 'https://ag-development.mk',
  logo: 'https://ag-development.mk/logo.svg',
  description: 'Веб страни, IT поддршка, дизајн на социјални мрежи и дигитален раст за мали бизниси во Македонија.',
  email: 'info@ag-development.mk',
  sameAs: [],
  serviceArea: { '@type': 'Country', name: 'Macedonia' },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="mk" className={`${outfit.variable} ${inter.variable}`}>
      <body className="font-sans antialiased">
        <CartProvider>{children}<ChatWidget /></CartProvider>
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(orgSchema) }} />
      </body>
    </html>
  )
}
