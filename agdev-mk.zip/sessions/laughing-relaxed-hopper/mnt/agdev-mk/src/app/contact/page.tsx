'use client'
import { useState } from 'react'
import { PublicHeader } from '@/components/public/Header'
import { PublicFooter } from '@/components/public/Footer'

export default function ContactPage() {
  const [sent, setSent] = useState(false)

  const info = [
    ['💬', 'Време на одговор', 'До 3 часа'],
    ['🕘', 'Работно време', '24/7'],
    ['🌎', 'Локација', 'Далечинска поддршка'],
  ]

  return (
    <>
      <PublicHeader />

      <section className="text-white py-16 px-6" style={{ background: 'linear-gradient(135deg, #0f1f3d 0%, #162b52 100%)' }}>
        <div className="max-w-2xl">
          <div className="text-xs font-bold uppercase tracking-widest text-blue-400 mb-3">Контакт</div>
          <h1 className="font-display text-4xl font-extrabold text-white mb-4">Стапете во контакт</h1>
          <p className="text-white/75 text-lg">Имате прашање за услугите или сакате да почнете? Пишете ни и ќе ви одговориме брзо.</p>
        </div>
      </section>

      <section className="py-20 px-6">
        <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-12">
          <div>
            <h2 className="font-display text-2xl font-extrabold text-slate-800 mb-6">Пратете ни порака</h2>
            {sent ? (
              <div className="bg-green-50 border border-green-200 rounded-xl p-6 text-center">
                <div className="text-3xl mb-3">✓</div>
                <h3 className="font-bold text-green-800 mb-2">Пораката е пратена!</h3>
                <p className="text-green-700 text-sm">Ќе ви одговориме во рок од 3 часа.</p>
              </div>
            ) : (
              <form onSubmit={e => { e.preventDefault(); setSent(true) }} className="space-y-4">
                <div>
                  <label className="form-label">Вашето име</label>
                  <input type="text" required className="form-input" placeholder="Марко Марковски" />
                </div>
                <div>
                  <label className="form-label">Емаил адреса</label>
                  <input type="email" required className="form-input" placeholder="marko@mojojbiznis.mk" />
                </div>
                <div>
                  <label className="form-label">Услуга</label>
                  <select className="form-input">
                    <option value="">— Изберете услуга —</option>
                    <option>Изработка на веб страна</option>
                    <option>Одржување на веб страна</option>
                    <option>IT поддршка</option>
                    <option>Социјални мрежи и дизајн</option>
                    <option>Бизнис емаил</option>
                    <option>Домен и DNS</option>
                    <option>Друго</option>
                  </select>
                </div>
                <div>
                  <label className="form-label">Порака</label>
                  <textarea required rows={4} className="form-input resize-none" placeholder="Опишете го вашиот проект или прашање..." />
                </div>
                <button type="submit" className="btn-primary w-full py-3.5 justify-center">Прати порака →</button>
              </form>
            )}
          </div>

          <div>
            <h2 className="font-display text-2xl font-extrabold text-slate-800 mb-6">Информации</h2>
            <div className="space-y-4 mb-8">
              {info.map(([icon, label, value]) => (
                <div key={label} className="flex items-start gap-4 p-4 rounded-xl bg-slate-50 border border-slate-200">
                  <span className="text-2xl">{icon}</span>
                  <div>
                    <div className="font-semibold text-slate-700 text-sm">{label}</div>
                    <div className="text-slate-600 text-sm mt-0.5">{value}</div>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-6 rounded-xl" style={{ background: 'linear-gradient(135deg, #0f1f3d, #1e3a5f)' }}>
              <h3 className="font-display font-bold text-white mb-2">Нова веб страна?</h3>
              <p className="text-white/65 text-sm mb-4">Добијте бесплатна ревизија и предлог за вашиот проект.</p>
              <a href="/review" className="inline-flex items-center gap-2 text-sm font-bold text-blue-300 hover:text-white transition-colors">
                Побарај бесплатна ревизија →
              </a>
            </div>
          </div>
        </div>
      </section>

      <PublicFooter />
    </>
  )
}
