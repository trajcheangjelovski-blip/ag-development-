'use client'
import { useState } from 'react'
import { PublicHeader } from '@/components/public/Header'
import { PublicFooter } from '@/components/public/Footer'

export default function ReviewPage() {
  const [sent, setSent] = useState(false)
  return (
    <>
      <PublicHeader />
      <section className="text-white py-16 px-6" style={{ background: 'linear-gradient(135deg, #0f1f3d 0%, #162b52 100%)' }}>
        <div className="max-w-2xl">
          <div className="text-xs font-bold uppercase tracking-widest text-blue-400 mb-3">Бесплатна услуга</div>
          <h1 className="font-display text-4xl font-extrabold text-white mb-4">Бесплатна ревизија на веб страна</h1>
          <p className="text-white/75 text-lg">Пратете ни ја вашата веб страна и ние ќе ја анализираме — брзина, SEO, дизајн, мобилна верзија и безбедност. Бесплатно, без обврски.</p>
        </div>
      </section>
      <section className="py-20 px-6">
        <div className="max-w-2xl mx-auto">
          {sent ? (
            <div className="text-center py-16">
              <div className="text-5xl mb-4">✓</div>
              <h2 className="font-display text-2xl font-extrabold text-slate-800 mb-3">Ревизијата е испратена!</h2>
              <p className="text-slate-600">Ќе ја прегледаме вашата страна и ќе ви испратиме детален извештај во рок од 24 часа.</p>
            </div>
          ) : (
            <form onSubmit={e => { e.preventDefault(); setSent(true) }} className="space-y-5">
              <div><label className="form-label">Вашето ime</label><input type="text" required className="form-input" placeholder="Марко Марковски" /></div>
              <div><label className="form-label">Емаил адреса</label><input type="email" required className="form-input" placeholder="marko@biznis.mk" /></div>
              <div><label className="form-label">URL на веб страната</label><input type="url" required className="form-input" placeholder="https://vasabiznis.mk" /></div>
              <div><label className="form-label">Главен проблем (опционално)</label><textarea rows={3} className="form-input resize-none" placeholder="Опишете го главниот проблем или она што сакате да го подобрите..." /></div>
              <button type="submit" className="btn-primary w-full py-3.5 justify-center text-base">Побарај бесплатна ревизија →</button>
              <p className="text-xs text-slate-400 text-center">Нема обврски. Ги чуваме вашите податоци приватни.</p>
            </form>
          )}
        </div>
      </section>
      <PublicFooter />
    </>
  )
}
