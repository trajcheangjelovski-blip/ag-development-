import Link from 'next/link'
import { PublicHeader } from '@/components/public/Header'
import { PublicFooter } from '@/components/public/Footer'
import { ServicesSection } from '@/components/public/ServicesSection'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Веб страни, IT Поддршка и Дигитален Раст за Мали Бизниси',
  description: 'AG Development им помага на мали бизниси во Македонија со веб страни, IT поддршка, бизнис емаил, дизајн на социјални мрежи и дигитален раст.',
  keywords: ['изработка на веб страна Македонија', 'IT поддршка', 'веб страна за мал бизнис', 'WordPress Македонија', 'дизајн на социјални мрежи'],
  openGraph: {
    title: 'AG Development — Веб страни, IT Поддршка и Дигитален Раст',
    description: 'Доверлива техничка помош за мали бизниси. Веб страни, IT, емаил, дизајн — сè далечински.',
    url: 'https://ag-development.mk',
  },
  alternates: { canonical: 'https://ag-development.mk' },
}

const iconProps = {
  width: 22, height: 22, viewBox: '0 0 24 24', fill: 'none',
  stroke: 'currentColor', strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round',
} as const

const whyUs = [
  {
    icon: (<svg {...iconProps}><rect x="2" y="7" width="20" height="14" rx="2" ry="2" /><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16" /></svg>),
    title: 'Без вработување на полно работно', desc: 'Стручна помош без плата. Плаќате само за она што го користите секој месец.',
  },
  {
    icon: (<svg {...iconProps}><rect x="1" y="4" width="22" height="16" rx="2" ry="2" /><line x1="1" y1="10" x2="23" y2="10" /></svg>),
    title: 'Фиксни месечни цени', desc: 'Знаете точно што е вклучено. Без изненадувачки сметки, без претпоставки.',
  },
  {
    icon: (<svg {...iconProps}><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z" /><line x1="4" y1="22" x2="4" y2="15" /></svg>),
    title: 'Македонска далечинска поддршка', desc: 'Тим кој ги разбира македонските мали бизниси. Јасна комуникација, секогаш.',
  },
  {
    icon: (<svg {...iconProps}><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" /><circle cx="12" cy="13" r="4" /></svg>),
    title: 'Доказ за секоја задача', desc: 'Слики пред и после, и белешки за завршување за секоја задача.',
  },
]

const steps = [
  ['Изберете план', 'Изберете го месечниот план за поддршка кој одговара на вашиот бизнис.'],
  ['Добијте пристап', 'Добијте логин за клиентскиот портал. Поднесувајте барања и следете сè.'],
  ['Поднесете барање', 'Опишете го проблемот или задачата. Прикачете слика ако е потребно.'],
  ['Ние го решаваме', 'Далечинска поддршка во рамки на вашиот договорен рок. Без посети.'],
  ['Видете доказ', 'Слики пред и после, и белешка за завршување откако работата е готова.'],
]

const testimonials = [
  { text: 'AG Development го поправи нашиот проблем со емаил за помалку од еден ден. Губевме клиенти и тие нè спасија.', name: 'Марија С.', biz: 'Цветна работилница', initials: 'МС', avatar: 'linear-gradient(135deg, #2563eb, #7c3aed)' },
  { text: 'Нашата веб страна имаше проблеми со продажбата со недели. Ги дијагностицираа за часови и документираа сè.', name: 'Никола Т.', biz: 'Авто сервис', initials: 'НТ', avatar: 'linear-gradient(135deg, #0891b2, #2563eb)' },
  { text: 'Пристапни, професионални и ги објаснуваат сите поправки. Конечно IT компанија која зборува јасен јазик.', name: 'Елена Л.', biz: 'Козметички салон', initials: 'ЕЛ', avatar: 'linear-gradient(135deg, #7c3aed, #db2777)' },
  { text: 'Немаме IT персонал. AG Development е всушност нашиот аутсорсиран IT тим.', name: 'Давид К.', biz: 'Агенција за недвижности', initials: 'ДК', avatar: 'linear-gradient(135deg, #0f1f3d, #2563eb)' },
]

function Stars() {
  return (
    <div className="flex gap-0.5 mb-4" aria-label="5 од 5 ѕвезди">
      {[...Array(5)].map((_, i) => (
        <svg key={i} width="15" height="15" viewBox="0 0 24 24" fill="#f59e0b">
          <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
        </svg>
      ))}
    </div>
  )
}

export default function HomePage() {
  return (
    <>
      <PublicHeader />

      {/* HERO */}
      <section className="relative overflow-hidden min-h-screen flex flex-col justify-center px-6 grain"
        style={{ background: 'linear-gradient(135deg, #060e1e 0%, #0a1628 30%, #0f1f3d 60%, #162b52 100%)' }}>
        <div className="absolute -top-40 -right-40 w-[900px] h-[900px] rounded-full pointer-events-none animate-float"
          style={{ background: 'radial-gradient(circle, rgba(37,99,235,0.55) 0%, rgba(37,99,235,0.15) 40%, transparent 70%)', filter: 'blur(50px)' }} />
        <div className="absolute -bottom-40 -left-20 w-[700px] h-[700px] rounded-full pointer-events-none animate-float-alt"
          style={{ background: 'radial-gradient(circle, rgba(124,58,237,0.50) 0%, rgba(124,58,237,0.15) 40%, transparent 70%)', filter: 'blur(55px)' }} />

        {/* Static orbit rings */}
        <div className="absolute pointer-events-none" style={{ top: '45%', left: '60%', transform: 'translate(-50%, -50%)' }}>
          <div className="absolute rounded-full border border-white/10" style={{ width: 520, height: 520, top: '50%', left: '50%', transform: 'translate(-50%,-50%)' }} />
          <div className="absolute rounded-full border border-white/[0.06]" style={{ width: 680, height: 680, top: '50%', left: '50%', transform: 'translate(-50%,-50%)' }} />
          <div className="absolute w-5 h-5 rounded-full animate-orbit-planet" style={{ background: 'radial-gradient(circle, #60a5fa, #2563eb)', boxShadow: '0 0 16px rgba(96,165,250,0.8)', top: '50%', left: '50%', marginTop: -10, marginLeft: -10 }} />
          <div className="absolute w-3 h-3 rounded-full animate-orbit-moon" style={{ background: 'radial-gradient(circle, #c084fc, #7c3aed)', boxShadow: '0 0 12px rgba(192,132,252,0.8)', top: '50%', left: '50%', marginTop: -6, marginLeft: -6 }} />
        </div>

        <div className="relative z-10 max-w-6xl mx-auto w-full py-32">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-xs font-semibold mb-8 animate-fade-up"
              style={{ background: 'rgba(37,99,235,0.15)', border: '1px solid rgba(37,99,235,0.3)', color: '#93c5fd' }}>
              <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse-dot" />
              Достапни за нови клиенти
            </div>

            <h1 className="font-display font-extrabold text-white leading-none mb-6 animate-fade-up-1"
              style={{ fontSize: 'clamp(42px, 6.5vw, 80px)', letterSpacing: '-0.02em' }}>
              Веб страна.<br />
              <span className="gradient-text">IT поддршка.</span><br />
              Дигитален раст.
            </h1>

            <p className="text-white/65 mb-8 leading-relaxed animate-fade-up-2" style={{ fontSize: 'clamp(16px, 1.8vw, 20px)', maxWidth: 560 }}>
              AG Development им помага на мали бизниси во Македонија да изгледаат професионално онлајн — без вработување на полно работно.
            </p>

            <div className="flex flex-wrap gap-4 animate-fade-up-3">
              <Link href="/review" className="btn-primary px-7 py-3.5 text-base">Бесплатна ревизија →</Link>
              <Link href="/pricing" className="btn-outline-white px-7 py-3.5 text-base">Погледни ценовник</Link>
            </div>

            <div className="flex flex-wrap items-center gap-6 mt-10 animate-fade-up-4">
              {[['✓', 'Без скриени трошоци'], ['✓', 'Фиксна месечна цена'], ['✓', 'Брз одговор']].map(([icon, text]) => (
                <div key={text} className="flex items-center gap-2 text-sm text-white/50">
                  <span className="text-blue-400 font-bold">{icon}</span>{text}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Why Us */}
      <section className="py-24 px-6 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-14">
            <div className="text-xs font-bold uppercase tracking-widest text-blue-600 mb-3">Зошто AG Development</div>
            <h2 className="font-display text-3xl lg:text-4xl font-extrabold text-slate-800">Техничка поддршка без изненадувања</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {whyUs.map(w => (
              <div key={w.title} className="text-center">
                <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto mb-4">{w.icon}</div>
                <h3 className="font-display font-bold text-slate-800 mb-2">{w.title}</h3>
                <p className="text-sm text-slate-500 leading-relaxed">{w.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services */}
      <ServicesSection />

      {/* How it works */}
      <section className="py-24 px-6" style={{ background: 'linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%)' }}>
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-14">
            <div className="text-xs font-bold uppercase tracking-widest text-blue-600 mb-3">Начин на работа</div>
            <h2 className="font-display text-3xl lg:text-4xl font-extrabold text-slate-800">Едноставно. Брзо. Транспарентно.</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-6">
            {steps.map(([title, desc], i) => (
              <div key={title} className="relative">
                <div className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-sm mb-4">{i + 1}</div>
                <h3 className="font-display font-bold text-slate-800 mb-2">{title}</h3>
                <p className="text-sm text-slate-500 leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 px-6 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-14">
            <div className="text-xs font-bold uppercase tracking-widest text-blue-600 mb-3">Рецензии на клиенти</div>
            <h2 className="font-display text-3xl font-extrabold text-slate-800">Мали бизниси ни веруваат</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {testimonials.map(t => (
              <div key={t.name} className="card p-6">
                <Stars />
                <p className="text-sm text-slate-600 leading-relaxed mb-5 italic">&ldquo;{t.text}&rdquo;</p>
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full flex items-center justify-center text-white text-xs font-bold" style={{ background: t.avatar }}>{t.initials}</div>
                  <div>
                    <div className="font-semibold text-sm text-slate-800">{t.name}</div>
                    <div className="text-xs text-slate-400">{t.biz}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 px-6 text-center text-white relative overflow-hidden"
        style={{ background: 'linear-gradient(135deg, #060e1e 0%, #0f1f3d 50%, #162b52 100%)' }}>
        <div className="relative z-10 max-w-2xl mx-auto">
          <h2 className="font-display text-3xl lg:text-4xl font-extrabold mb-4">Подготвени да започнете?</h2>
          <p className="text-white/65 text-lg mb-8">Добијте бесплатна ревизија на вашата веб страна или изберете план кој одговара на вашиот бизнис.</p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/review" className="btn-primary px-8 py-4 text-base">Бесплатна ревизија →</Link>
            <Link href="/pricing" className="btn-outline-white px-8 py-4 text-base">Погледни ценовник</Link>
          </div>
        </div>
      </section>

      <PublicFooter />
    </>
  )
}
