import { PublicHeader } from '@/components/public/Header'
import { PublicFooter } from '@/components/public/Footer'
import Link from 'next/link'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Портфолио',
  description: 'Реални клиентски веб страни изградени и одржувани од AG Development во Македонија.',
  alternates: { canonical: 'https://ag-development.mk/portfolio' },
}

const demos = [
  { slug: 'restaurant', name: 'Белла Кучина', type: 'Ресторан веб страна', desc: 'Целосно мени, фото галерија и резервации на маси за италијански ресторан.', tags: ['WordPress', 'Мени', 'Резервации'], grad: 'linear-gradient(135deg, #b45309 0%, #1a1410 120%)' },
  { slug: 'dental', name: 'БрајтСмајл Стоматологија', type: 'Клиника веб страна', desc: 'Страни за услуги, профили на тим и онлајн закажување за стоматолошка клиника.', tags: ['WordPress', 'Закажување', 'SEO'], grad: 'linear-gradient(135deg, #38bdf8 0%, #0c4a6e 120%)' },
  { slug: 'fitness', name: 'ПулсФит Студио', type: 'Фитнес веб страна', desc: 'Распоред на часови, ценовник и профили на тренери за теретана.', tags: ['WordPress', 'Ценовник', 'Распоред'], grad: 'linear-gradient(135deg, #65a30d 0%, #0b0f0a 120%)' },
  { slug: 'store', name: 'Урбан Трендови', type: 'Онлајн продавница', desc: 'Мрежа на производи, категории, значки за попуст и лејаут за онлајн продавница.', tags: ['WooCommerce', 'Е-трговија', 'Производи'], grad: 'linear-gradient(135deg, #57534e 0%, #1c1917 120%)' },
]

const clients = [
  { name: 'Муровска Меана', url: 'https://murovskameana.mk', type: 'Ресторан веб страна', location: 'Скопје, Македонија', desc: 'Традиционален македонски ресторан — прилагодена веб страна со повеќејазична поддршка (МК/АНГ), целосно мени, галерија, резервации и Wolt интеграција.', tags: ['Прилагодена изградба', 'Повеќејазична', 'Резервации'], role: 'Изградба + месечна грижа', grad: 'linear-gradient(135deg, #7c1d0e 0%, #c0392b 40%, #8b4513 100%)', accent: '#c0392b', icon: '🍽️', year: '2023' },
  { name: 'Cross Bearers MK', url: 'https://crossbearers.mk', type: 'Мото клуб', location: 'Велес, Македонија', desc: 'Веб страна за мото братство со календар на настани, фото галерија, блог, историја на клубот и хуманитарни активности — изградена на WordPress со Elementor.', tags: ['WordPress', 'Elementor', 'Настани'], role: 'Изградба + месечна грижа', grad: 'linear-gradient(135deg, #111111 0%, #1a1a1a 50%, #2d1f0e 100%)', accent: '#d97706', icon: '🏍️', year: '2024' },
]

export default function PortfolioPage() {
  return (
    <>
      <PublicHeader />

      <section className="text-white py-16 px-6" style={{ background: 'linear-gradient(135deg, #0f1f3d 0%, #162b52 100%)' }}>
        <div className="max-w-2xl">
          <div className="text-xs font-bold uppercase tracking-widest text-blue-400 mb-3">Мојата работа</div>
          <h1 className="font-display text-4xl font-extrabold text-white mb-4">Реални клиентски веб страни</h1>
          <p className="text-white/75 text-lg">Ова се реални бизниси со кои работам — од лансирање до секојдневна грижа. Секоја страна е жива, работи и под моја поддршка.</p>
        </div>
      </section>

      {/* Real clients */}
      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="mb-10">
            <div className="text-xs font-bold uppercase tracking-widest text-blue-600 mb-2">Клиентски веб страни</div>
            <h2 className="font-display text-2xl sm:text-3xl font-extrabold text-slate-800 mb-3">Страни кои ги изградив и одржувам</h2>
            <p className="text-slate-600 max-w-2xl">Секој проект подолу е реален клиент — ја изградив нивната веб страна и продолжувам да се грижам за хостинг, ажурирања и поддршка секој месец.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {clients.map(w => (
              <div key={w.url} className="card overflow-hidden hover:-translate-y-1 hover:shadow-xl transition-all">
                <div className="relative flex flex-col justify-end p-7" style={{ background: w.grad, minHeight: 200 }}>
                  <span className="absolute top-4 right-4 text-xs font-bold px-2.5 py-1 rounded-full" style={{ background: 'rgba(255,255,255,0.15)', color: 'white' }}>Од {w.year}</span>
                  <div className="text-4xl mb-3">{w.icon}</div>
                  <div className="font-display font-extrabold text-white text-2xl leading-tight">{w.name}</div>
                  <div className="text-white/65 text-sm mt-1 font-medium">{w.type} · {w.location}</div>
                </div>
                <div className="p-6">
                  <p className="text-sm text-slate-600 leading-relaxed mb-4">{w.desc}</p>
                  <div className="flex flex-wrap gap-1.5 mb-4">
                    {w.tags.map(t => <span key={t} className="text-xs bg-slate-100 text-slate-600 px-2.5 py-0.5 rounded-full font-medium">{t}</span>)}
                  </div>
                  <div className="text-xs font-semibold px-3 py-2 rounded-lg mb-5" style={{ background: '#f0fdf4', color: '#166534' }}>✓ {w.role}</div>
                  <a href={w.url} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 text-sm font-bold px-5 py-2.5 rounded-lg text-white transition-all hover:-translate-y-0.5" style={{ background: w.accent, boxShadow: `0 4px 16px ${w.accent}55` }}>
                    Посети ја веб страната →
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Demos */}
      <section className="py-20 px-6 bg-slate-50 border-y border-slate-200">
        <div className="max-w-6xl mx-auto">
          <div className="mb-8">
            <div className="text-xs font-bold uppercase tracking-widest text-blue-600 mb-2">Демо страни</div>
            <h2 className="font-display text-2xl sm:text-3xl font-extrabold text-slate-800 mb-3">Веб страни кои ги изградив</h2>
            <p className="text-slate-600 max-w-2xl mb-3">Ова се само frontend демо изградби — дизајнот, распоредот и UI се целосно изградени, но не вклучуваат реален backend или интеграции.</p>
            <div className="inline-flex items-center gap-2 text-xs font-semibold px-3 py-1.5 rounded-full" style={{ background: '#fef9c3', color: '#854d0e' }}>
              ⚠️ Само frontend демо — не е жива бизнис страна
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {demos.map(w => (
              <Link key={w.slug} href={`/demos/${w.slug}`} target="_blank" rel="noreferrer" className="card overflow-hidden hover:-translate-y-1 hover:shadow-xl transition-all group">
                <div className="h-52 flex items-center justify-center relative" style={{ background: w.grad }}>
                  <div className="text-center">
                    <div className="font-display font-extrabold text-white text-2xl drop-shadow">{w.name}</div>
                    <div className="text-white/70 text-xs mt-1 uppercase tracking-widest">{w.type}</div>
                  </div>
                  <span className="absolute bottom-3 right-3 bg-white/90 text-slate-900 text-xs font-bold px-3 py-1.5 rounded-full opacity-0 group-hover:opacity-100 transition-opacity">Отвори демо →</span>
                </div>
                <div className="p-5">
                  <h3 className="font-display font-bold text-slate-800 mb-2">{w.name}</h3>
                  <p className="text-sm text-slate-500 leading-relaxed mb-3">{w.desc}</p>
                  <div className="flex flex-wrap gap-1.5">
                    {w.tags.map(t => <span key={t} className="text-xs bg-slate-100 text-slate-600 px-2.5 py-0.5 rounded-full font-medium">{t}</span>)}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 px-6 text-center text-white" style={{ background: '#0f1f3d' }}>
        <h2 className="font-display text-3xl font-extrabold mb-3">Сакате слична веб страна?</h2>
        <p className="text-white/70 mb-7">Ќе ви изградам чиста, модерна страна и ќе се грижам за сè — од хостинг до месечни ажурирања.</p>
        <div className="flex flex-wrap justify-center gap-3">
          <Link href="/review" className="btn-primary px-7 py-3.5">Бесплатна ревизија →</Link>
          <Link href="/contact" className="btn-outline-white px-7 py-3.5">Почнете го вашиот проект</Link>
        </div>
      </section>

      <PublicFooter />
    </>
  )
}
