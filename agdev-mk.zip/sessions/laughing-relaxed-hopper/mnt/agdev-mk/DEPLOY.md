# Deploying Both Sites on the Same Server

## Architecture

```
Internet
    │
    ▼
Caddy (agdev-pro)          ports 80 + 443
    ├── ag-development.dev  →  app:3000      (agdev-pro Next.js)
    └── ag-development.mk   →  mk_app:3000   (agdev-mk Next.js)
```

One Caddy instance in `agdev-pro` handles both domains and auto-provisions
SSL certificates for both via Let's Encrypt.

---

## Before You Start

1. **DNS** — Point both A records at your server's public IP:
   - `ag-development.dev` → `<server IP>`
   - `www.ag-development.dev` → `<server IP>`
   - `ag-development.mk` → `<server IP>`
   - `www.ag-development.mk` → `<server IP>`

2. **Ports** — Ensure ports 80 and 443 are open in your server firewall.

---

## First-Time Deployment

### 1. Upload agdev-mk to the server

```bash
# From your local machine (adjust paths as needed)
scp -r C:/Users/MCASH/Desktop/agdev-mk root@<server-ip>:/root/agdev-mk
```
Or use git (recommended — push to GitHub first, then pull on server):
```bash
# On server
git clone https://github.com/YOUR_USERNAME/agdev-mk.git /root/agdev-mk
```

### 2. Fill in real environment variables on the server

```bash
# On server — edit the MK site's env file
nano /root/agdev-mk/.env.production
```
Fill in your real Supabase keys and Resend API key for the MK project.

### 3. Stop the running EN site (briefly)

```bash
cd /root/agdev-pro
docker compose down
```

### 4. Start both sites together

```bash
cd /root/agdev-pro
docker compose up -d --build
```

This builds both apps and starts them along with Caddy. Caddy will
automatically fetch SSL certificates for both domains (takes ~30s on
first run — both domains must be live in DNS first).

### 5. Verify

```bash
docker compose ps          # all 3 containers should be "Up"
docker compose logs caddy  # look for "certificate obtained" for both domains
curl https://ag-development.dev
curl https://ag-development.mk
```

---

## Day-to-Day: Updating One Site

### Update the EN site only

```bash
cd /root/agdev-pro
git pull                                    # pull latest code
docker compose up -d --build app            # rebuild only the EN app, no downtime
```

### Update the MK site only

```bash
cd /root/agdev-mk
git pull                                    # pull latest code
cd /root/agdev-pro
docker compose up -d --build mk_app         # rebuild only the MK app, no downtime
```

Caddy and the other app keep running untouched.

---

## Local Development

Run each site locally at the same time:

```bash
# Terminal 1 — EN site at http://localhost:3000
cd agdev-pro
npm run dev

# Terminal 2 — MK site at http://localhost:3001
cd agdev-mk
npm run dev -- -p 3001
```

Or use the MK docker-compose for a production-like local build:
```bash
cd agdev-mk
docker compose up --build   # runs at http://localhost:3001
```

---

## Useful Commands

| Command | What it does |
|---------|-------------|
| `docker compose ps` | Show running containers |
| `docker compose logs -f app` | Stream EN app logs |
| `docker compose logs -f mk_app` | Stream MK app logs |
| `docker compose logs -f caddy` | Stream Caddy/SSL logs |
| `docker compose restart mk_app` | Restart MK app without rebuild |
| `docker compose down` | Stop everything |
| `docker compose up -d --build` | Rebuild and start everything |
